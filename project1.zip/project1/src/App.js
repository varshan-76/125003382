import "./App.css";

function App() {
  return (
    <div className="App">
      <p>Company name:Gomart</p>
      <p>Owner name:Rahul</p>
      <p>toekn:Bearer</p>
      <p>email:Rahul@1234</p>
    </div>
  );
}

export default App;
